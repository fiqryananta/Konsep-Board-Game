# Konsep-Board-Game
Tugas Kelompok 4 Mata Kuliah Proyek Perangkat Lunak (PPL) 4624 SC

1. Muhammad Fiqry Ananta Jusna Saputra -  A11.2018.11178
2. Dwi Rahman - A11.2018.10921
3. Muhammad Amir Ma'ruf - A11.2018.11571
4. Ahmad Yusuf Abdillah - A11.2018.10844
5. Elia Edi Saputra - A11.2018.10869
